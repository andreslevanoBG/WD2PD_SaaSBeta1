sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("shapein.MonitoringOrganizations.controller.DetailObjectNotFound", {});
});